clear all; close all; clc
global eta lambda eps
global index ts u
index = 1;

eta = 3;
eps = 0.1;
lambda = 1.5;

ts = 0.01;
ns = 12; %number of states (2 * No of DOF)

% th1 = pi/2; th2 = 0; th3 = pi/2; th4 = 0; th5 = 0; th6 = -pi/2; 

load('desired_theta.mat')

x0 = [    theta_des(1,1)     theta_des(2,1)     theta_des(3,1)     theta_des(4,1)     theta_des(5,1)      theta_des(6,1) ...
      theta_des_dot(1,1) theta_des_dot(2,1) theta_des_dot(3,1) theta_des_dot(4,1) theta_des_dot(5,1) theta_des_dot(6,1)]; %Initial conditions
load('time_span.mat')
u = zeros(6,length(time_span));

[tt, xx] = ode45('robot_der',time_span,x0);

figure()
subplot(321)
plot(tt,u(1,:)), grid on
ylabel('u1')
subplot(322)
plot(tt,u(2,:)), grid on
ylabel('u2')
subplot(323)
plot(tt,u(3,:)), grid on
ylabel('u3')
subplot(324)
plot(tt,u(4,:)), grid on
ylabel('u4')
subplot(325)
plot(tt,u(5,:)), grid on
ylabel('u5')
subplot(326)
plot(tt,u(6,:)), grid on
ylabel('u6')
suptitle('Control inputs')

figure()
subplot(321)
plot(tt,theta_des(1,:)*180/pi,tt, xx(:,1)'*180/pi)
ylabel('\theta_{1}'), grid on
legend('des','act')
subplot(322)
plot(tt,theta_des(2,:)*180/pi,tt,xx(:,2)'*180/pi)
ylabel('\theta_{2}'), grid on
legend('des','act')
subplot(323)
plot(tt,theta_des(3,:)*180/pi,tt,xx(:,3)'*180/pi)
ylabel('\theta_{3}'), grid on
legend('des','act')
subplot(324)
plot(tt,theta_des(4,:)*180/pi,tt,xx(:,4)'*180/pi)
ylabel('\theta_{4}'), grid on
legend('des','act')
subplot(325)
plot(tt,theta_des(5,:)*180/pi,tt,xx(:,5)'*180/pi)
ylabel('\theta_{5}'), grid on
legend('des','act')
subplot(326)
plot(tt,theta_des(6,:)*180/pi,tt,xx(:,6)'*180/pi)
ylabel('\theta_{6}'), grid on
suptitle('\theta: DESIRED vs ACTUAL [deg]')
legend('des','act')

figure()
subplot(321)
plot(tt,theta_des_dot(1,:)*180/pi,tt, xx(:,7)'*180/pi)
ylabel('\theta_{1}'), grid on
legend('des','act')
subplot(322)
plot(tt,theta_des_dot(2,:)*180/pi,tt,xx(:,8)'*180/pi)
ylabel('\theta_{2}'), grid on
legend('des','act')
subplot(323)
plot(tt,theta_des_dot(3,:)*180/pi,tt,xx(:,9)'*180/pi)
ylabel('\theta_{3}'), grid on
legend('des','act')
subplot(324)
plot(tt,theta_des_dot(4,:)*180/pi,tt,xx(:,10)'*180/pi)
ylabel('\theta_{4}'), grid on
legend('des','act')
subplot(325)
plot(tt,theta_des_dot(5,:)*180/pi,tt,xx(:,11)'*180/pi)
ylabel('\theta_{5}'), grid on
legend('des','act')
subplot(326)
plot(tt,theta_des_dot(6,:)*180/pi,tt,xx(:,12)'*180/pi)
ylabel('\theta_{6}'), grid on
suptitle('\theta dot: DESIRED vs ACTUAL [deg]')
legend('des','act')

figure()
subplot(321)
plot(tt,(theta_des_dot(1,:)-xx(:,7)')*180/pi)
ylabel('\theta_{1}'), grid on
subplot(322)
plot(tt,(theta_des_dot(2,:)-xx(:,8)')*180/pi)
ylabel('\theta_{2}'), grid on
subplot(323)
plot(tt,(theta_des_dot(3,:)-xx(:,9)')*180/pi)
ylabel('\theta_{3}'), grid on
subplot(324)
plot(tt,(theta_des_dot(4,:)-xx(:,10)')*180/pi)
ylabel('\theta_{4}'), grid on
subplot(325)
plot(tt,(theta_des_dot(5,:)-xx(:,11)')*180/pi)
ylabel('\theta_{5}'), grid on
subplot(326)
plot(tt,(theta_des_dot(6,:)-xx(:,12)')*180/pi)
ylabel('\theta_{6}'), grid on
suptitle('\theta: tracking error(t) [deg]')

figure()
subplot(321)
plot(tt,(theta_des_dot(1,:)-xx(:,7)')*180/pi)
ylabel('\theta_{1}'), grid on
subplot(322)
plot(tt,(theta_des_dot(2,:)-xx(:,8)')*180/pi)
ylabel('\theta_{2}'), grid on
subplot(323)
plot(tt,(theta_des_dot(3,:)-xx(:,9)')*180/pi)
ylabel('\theta_{3}'), grid on
subplot(324)
plot(tt,(theta_des_dot(4,:)-xx(:,10)')*180/pi)
ylabel('\theta_{4}'), grid on
subplot(325)
plot(tt,(theta_des_dot(5,:)-xx(:,11)')*180/pi)
ylabel('\theta_{5}'), grid on
subplot(326)
plot(tt,(theta_des_dot(6,:)-xx(:,12)')*180/pi)
ylabel('\theta_{6}'), grid on
suptitle('\theta dot: tracking error(t) [deg/sec]')